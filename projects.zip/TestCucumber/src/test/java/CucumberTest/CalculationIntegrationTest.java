package CucumberTest;



import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"classpath:features/test.feature"}
		,plugin={"pretty","html:target/reports"}
		,glue={"com.cg.calculator.Calculator"}
		)
public class CalculationIntegrationTest {

}
