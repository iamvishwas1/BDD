package shouty;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdefs {
	//@Given("^Tom is (15) metres from Jack$")
	//@Given("Tom is (..) metres from Jack")
	//@Given("^Tom is (.*) metres from Jack$")
	//@Given("^Tom is ([0123456789]*) metres from Jack$")
	//@Given("^Tom is ([0-9]*) metres from Jack$")
	//@Given("^Tom is (\\d+) metres from Jack$")
	@Given("(\\w+) (?:is|is standing) (\\d+) metre? from (\\w+)")
	public void tom_is_from_Jack(String name1,int distance,String name2) throws Throwable {
	    System.out.println("Distance:" + distance);
	}


	@When("^Jack Shouts \"(.*?)\"$")
	public void jack_Shouts(String arg1) throws Throwable {
	   
	}

	@Then("^Tom hears Jack messages$")
	public void tom_hears_Jack_messages() throws Throwable {
	    
	}

}
